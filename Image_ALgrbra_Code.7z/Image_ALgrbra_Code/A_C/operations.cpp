#include "hls_video.h"
#include "ap_axi_sdata.h"
#include <stdio.h>
#include <hls_math.h>
#include <ap_int.h>
#include <stdlib.h>
#include <ap_fixed.h>

#define IMAGE_I			256
#define IMAGE_J			256
#define KERNEL_DIM		3
#define IMAGE_BIT		8
#define IMAGE_MAX_VAL	256
#define IMAGE_BORDER	255
//operation 1:
//op1: 1:* 2:+ 3:and 4:or 5:convolution
void op11(int window[KERNEL_DIM][KERNEL_DIM], char kernel[KERNEL_DIM*KERNEL_DIM],int L,unsigned int K_rotate){
	int i, j;
	int counter = 0;
	int Kernel_L[KERNEL_DIM][KERNEL_DIM];
	int Kernel_R[KERNEL_DIM][KERNEL_DIM];
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			Kernel_L[i][j] = kernel[counter];
			counter++;
		}
	}
	if( (K_rotate==90)&&(L==1) ){
		for (i=0;i<KERNEL_DIM;i++){
			for (j=0;j<KERNEL_DIM;j++){
				Kernel_R[i][j] = Kernel_L[j][i];
			}
		}
	}
	else{
		for (i=0;i<KERNEL_DIM;i++){
			for (j=0;j<KERNEL_DIM;j++){
				Kernel_R[i][j] = Kernel_L[i][j];
			}
		}
	}
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			window[i][j] = window[i][j] * Kernel_R[i][j];
			counter++;
		}
	}
}
void op12(int window[KERNEL_DIM][KERNEL_DIM], char kernel[KERNEL_DIM*KERNEL_DIM],int L,unsigned int K_rotate){
	int i, j;
	int counter = 0;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			window[i][j] = window[i][j] + kernel[counter];
			counter++;
		}
	}
}
void op13(int window[KERNEL_DIM][KERNEL_DIM], char kernel[KERNEL_DIM*KERNEL_DIM],int L,unsigned int K_rotate){
	int i, j;
	int counter = 0;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			window[i][j] = (window[i][j]) && (kernel[counter]);
			counter++;
		}
	}
}
void op14(int window[KERNEL_DIM][KERNEL_DIM], char kernel[KERNEL_DIM*KERNEL_DIM],int L,unsigned int K_rotate){
	int i, j;
	int counter = 0;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			window[i][j] = (window[i][j]) || (kernel[counter]);
			counter++;
		}
	}
}
short op15(int window[KERNEL_DIM][KERNEL_DIM], char kernel[KERNEL_DIM*KERNEL_DIM],int L,unsigned int K_rotate){
	short conv_result;
	int i, j;
	int temp = 0;
	int counter = 0;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
#pragma HLS PIPELINE
			temp = temp + window[i][j] * kernel[counter];
			counter++;
		}
	}
	if (temp>=IMAGE_MAX_VAL){
		temp = 15;
	}
	if (temp<0){
		temp = 0;
	}
	conv_result = temp;
	return conv_result;
}
void op16(int window[KERNEL_DIM][KERNEL_DIM],char kernel[KERNEL_DIM*KERNEL_DIM],unsigned int label_counter[1]){
	int i, j;
	int counter = 0;
	int windowMin = 255;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			window[i][j] = window[i][j] * kernel[counter] * label_counter[1];
			counter++;
			if ( (window[i][j]<=windowMin)&&(window[i][j]!=0)){
				windowMin = window[i][j];
			}
		}
	}
	if(window[1][1]!=0){
		for (i=0;i<KERNEL_DIM;i++){
			for (j=0;j<KERNEL_DIM;j++){
				if (window[i][j]!=0){
					window[i][j] = windowMin;
				}
			}
		}
	}
	label_counter[0] = label_counter[0] + 1;
}
//operation 2:
//op2: 0: nothing, 1: sum, 2:min, 3:max 4: sum abs
short op20(int window[KERNEL_DIM][KERNEL_DIM]){
	short result;
	result = window[1][1];
	return result;
}
short op21(int window[KERNEL_DIM][KERNEL_DIM]){
	short sum_result;
	int temp = 0;
	int i, j;
	int counter = 0;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			temp = temp + window[i][j];
		}
	}
	if (temp>=IMAGE_MAX_VAL){
		sum_result = IMAGE_MAX_VAL-1;
	}
	else if (temp<0){
		sum_result = 0;
	}
	else{
		sum_result = temp;
	}
	return sum_result;
}
short op22(int window[KERNEL_DIM][KERNEL_DIM]){
	short min_result = IMAGE_MAX_VAL;
	int temp_min = IMAGE_MAX_VAL;
	int i, j;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			if (window[i][j]<=temp_min){
				temp_min = window[i][j];
			}
		}
	}
	if (temp_min<0){
		min_result = 0;
	}
	else if(temp_min>=IMAGE_MAX_VAL){
		min_result = IMAGE_MAX_VAL-1;
	}
	else {
		min_result = temp_min;
	}
	return min_result;
}
short op23(int window[KERNEL_DIM][KERNEL_DIM]){
	short max_result = 0;
	int temp_max = 0;
	int i, j;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			if (window[i][j]>=max_result){
				max_result = window[i][j];
			}
		}
	}
	if (temp_max<0){
		max_result = 0;
	}
	else if(temp_max>=IMAGE_MAX_VAL){
		max_result = IMAGE_MAX_VAL-1;
	}
	else {
		max_result = temp_max;
	}
	return max_result;
}
short op24(int window[KERNEL_DIM][KERNEL_DIM]){
	short sum_result = 0;
	int i,j;
	int counter = 0;
	for (i=0;i<KERNEL_DIM;i++){
		for (j=0;j<KERNEL_DIM;j++){
			sum_result = sum_result + window[i][j];
		}
	}
	sum_result = abs(sum_result);
	if (sum_result>=IMAGE_MAX_VAL){
		sum_result = IMAGE_MAX_VAL-1;
	}
	return sum_result;
}
//operation 3:
//op3: 0: nothing, 1: thresholding 2:count pixels equal 3: count pixels above 4: count pixels less
unsigned char op31(ap_uint<IMAGE_BIT> inpix, unsigned char value){
	unsigned char out_value;
	if (inpix>=value){
		out_value = IMAGE_MAX_VAL-1;
	}
	else{
		out_value = 0;
	}
	return out_value;
}
unsigned int op32(ap_uint<IMAGE_BIT> inpix, unsigned char value, unsigned int currentVal){
	unsigned int out_value;
	out_value = currentVal;
	if (inpix==value){
		out_value++;
	}
	return out_value;
}
unsigned int op33(ap_uint<IMAGE_BIT> inpix, unsigned char value, unsigned int currentVal){
	unsigned int out_value;
	out_value = currentVal;
	if (inpix>=value){
		out_value++;
	}
	return out_value;
}
unsigned int op34(ap_uint<IMAGE_BIT> inpix, unsigned char value, unsigned int currentVal){
	unsigned int out_value;
	out_value = currentVal;
	if (inpix<=value){
		out_value++;
	}
	return out_value;
}






