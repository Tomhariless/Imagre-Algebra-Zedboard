#include "Image_algebra_core.h"
#include "test.h"

using namespace std;

int main(){
	FILE *fp;
	fp = fopen("C:\\Users\\40148119\\TextureFeature\\HLS_Project\\Image_algebra\\Image_algebra_DMA\\result\\ImageA_out.txt","w+");
	hls::stream<uint_side_channel> inStream;
	hls::stream<uint_side_channel> outStream;
	uint_side_channel valIn;
	uint_side_channel result;
	int result_data;
	for (int idx=0;idx<(IMAGE_I*IMAGE_J);idx++){
		valIn.data = lena[idx];
		valIn.keep = 1; valIn.strb = 1; valIn.user = 1; valIn.id = 0; valIn.dest = 0;
		inStream<<valIn;
	}
	int op1=1;
	int op2=1;
	int op3=0;
	int op3Val=0;
	char kernel[KERNEL_DIM*KERNEL_DIM]={
			-1, -1, -1,
			-1,  8, -1,
			-1, -1, -1
	};
	Image_algebraDMA(inStream,outStream,op1,kernel,op2,op3,op3Val);
	for (int idx=0;idx<(IMAGE_I*IMAGE_J);idx++){
		outStream.read(result);
		result_data = result.data;
		fprintf(fp,"%d \n",result_data);
	}
	fclose(fp);
}
